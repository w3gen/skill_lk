
jQuery(document).ready(function($){
    'use strict';

    if (typeof $.fn.timepicker !== 'undefined') {
        $('.thm-schedual .thm-time-picker').timepicker();
    }
});
